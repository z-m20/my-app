import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contenu',
  templateUrl: './contenu.component.html',
  styleUrls: ['./contenu.component.css']
})
export class ContenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
